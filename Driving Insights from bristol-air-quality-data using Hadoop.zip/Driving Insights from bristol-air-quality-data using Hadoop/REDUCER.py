#!/usr/bin/python
from itertools import groupby
from operator import itemgetter
import sys

#reducer will write all the output in the file data values after jan12010
def write_data(file):
    f = open('croped_data.txt','w')
    for line in file:
       f.write(line)
    f.close()

      # print(line)
def main():
    write_data(sys.stdin)
    f = open("croped_data.txt","r")
    print(f.read())

main()
