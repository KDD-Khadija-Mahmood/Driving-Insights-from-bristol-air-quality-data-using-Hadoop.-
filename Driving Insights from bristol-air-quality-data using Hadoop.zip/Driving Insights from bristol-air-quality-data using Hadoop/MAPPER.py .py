
MAPPER.py
Task1.1

#!/usr/bin/python
import sys
All_rows=[]
years=[]
Croped_data = []
count =0
for line in sys.stdin:
    line = line.strip()
    All_rows.append(line)

del All_rows[0]
#print(All_rows[0])

check = 2010
for y in All_rows:
     year=y.split('-')[0]


     try:
        year2=int(year)
        if year2 > check:
                Croped_data.append(y)
     except:
        count = count+1


for j in  Croped_data:
        print(j)
print(count)

i =0
for details in Croped_data:
  print(details)
  i=i+1
  if(i==10):
     break
